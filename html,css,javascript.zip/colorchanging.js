function myfun()
{
    var r=Math.random();
    var g=Math.random();
    var b=Math.random();
    document.body.style.backgroundColor=rgb(Math.floor(255*r),Math.floor(255*g),Math.floor(255*b));
}
function myfun1()
{
   
    document.bgColor="red";
}